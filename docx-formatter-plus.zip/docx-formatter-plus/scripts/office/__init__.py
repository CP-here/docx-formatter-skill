# Office document manipulation utilities
